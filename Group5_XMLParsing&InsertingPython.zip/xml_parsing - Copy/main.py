import xml.etree.ElementTree as ET
import pyodbc

conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};'
                      'Server=DESKTOP-DBHTGT3;'
                      'Database=XMLParsing;'
                      'Trusted_Connection=yes;')
xml = "customers.xml"
tree = ET.parse(xml)
root = tree.getroot()
count = 0

# for customer in root.findall('{http://schemas.datacontract.org/2004/07/DataGenerator}Customer'):
#     name = customer.find('{http://schemas.datacontract.org/2004/07/DataGenerator}Name').text
#     customer_id = customer.find('{http://schemas.datacontract.org/2004/07/DataGenerator}CustomerId').text
#     age = customer.find('{http://schemas.datacontract.org/2004/07/DataGenerator}Age').text
#     email = customer.find('{http://schemas.datacontract.org/2004/07/DataGenerator}Email').text
#
#     customer = """INSERT INTO dbo.Customers (CustomerID,CustomerName,CustomerEmail,CustomerAge)
#                                VALUES(?,?,?,?)"""
#     cursor = conn.cursor()
#     cursor.execute(customer, (customer_id, name, email, age))
#     conn.commit()
#     print("Customers Inserted Successfully")


# for customer in root.findall('{http://schemas.datacontract.org/2004/07/DataGenerator}Customer'):
#     for orders in customer.findall("{http://schemas.datacontract.org/2004/07/DataGenerator}Orders"):
#         for order in orders.findall("{http://schemas.datacontract.org/2004/07/DataGenerator}Order"):
#             customer_id = order.find('{http://schemas.datacontract.org/2004/07/DataGenerator}CustomerId').text
#             order_id = order.find('{http://schemas.datacontract.org/2004/07/DataGenerator}OrderId').text
#             total = order.find('{http://schemas.datacontract.org/2004/07/DataGenerator}Total').text
#
#             customer = """INSERT INTO dbo.Orders (OrderID, CustomerID, Total)
#                                                VALUES(?,?,?)"""
#             cursor = conn.cursor()
#             cursor.execute(customer, (order_id, customer_id, total))
#             conn.commit()
#             print("Orders Inserted Successfully")

for customer in root.findall('{http://schemas.datacontract.org/2004/07/DataGenerator}Customer'):
    for orders in customer.findall("{http://schemas.datacontract.org/2004/07/DataGenerator}Orders"):
        for order in orders.findall("{http://schemas.datacontract.org/2004/07/DataGenerator}Order"):
            # one or many times
            for line in order.findall("{http://schemas.datacontract.org/2004/07/DataGenerator}Lines"):
                for orderLine in line.findall("{http://schemas.datacontract.org/2004/07/DataGenerator}OrderLine"):
                    order_line_id = orderLine.find('{http://schemas.datacontract.org/2004/07/DataGenerator}OrderLineId').text
                    price = orderLine.find('{http://schemas.datacontract.org/2004/07/DataGenerator}Price').text
                    product_id = orderLine.find('{http://schemas.datacontract.org/2004/07/DataGenerator}ProductId').text
                    qty = orderLine.find('{http://schemas.datacontract.org/2004/07/DataGenerator}ProductId').text
                    total = orderLine.find('{http://schemas.datacontract.org/2004/07/DataGenerator}Total').text
                    order_id = order.find('{http://schemas.datacontract.org/2004/07/DataGenerator}OrderId').text

                    customer = """INSERT INTO dbo.OrderLines (OrderLineId, OrderId, Qty, Price, LineTotal, ProductId)
                                                                       VALUES(?, ?, ?, ?, ?, ?)"""
                    cursor = conn.cursor()
                    cursor.execute(customer, (order_line_id, order_id, qty, price, total, product_id))
                    conn.commit()
                    count += 1
                    print(count)
